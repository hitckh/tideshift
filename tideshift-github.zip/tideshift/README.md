# TIDESHIFT

A small browser-based puzzle game prototype. Place block shapes, clear full rows or columns, and plan around rotating gravity.

## Play locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. No build step, dependencies, or server are required.

## Controls

- Select one of the three available pieces.
- Tap/click a starting cell on the board to place it.
- Use **Rotate** or **Flip** before placing a piece.
- Complete full rows or columns to clear them.
- Gravity rotates clockwise after each placement: down → left → up → right.

## Current prototype features

- 8×8 board
- Random polyomino pieces
- Piece rotation and reflection
- Rotating directional gravity
- Row and column clears
- Score and locally saved best score
- Responsive layout for mobile and desktop
- No timer or lives

## Research connection

The prototype is intended to explore a low-intensity puzzle format involving:
- **Visuospatial processing:** fitting, rotating, and tracking shapes as the board shifts.
- **Logical planning:** anticipating how a placement will change future board states.
- **Controlled stimulation:** no countdown, forced streak, or punishment for taking time.
- **Auditory design:** sound is not implemented in this first prototype; an optional, adjustable sound layer could be tested later.

This is a game-design hypothesis, not a validated stress-reduction intervention. The prototype does not diagnose, prevent, or treat stress, burnout, or derealization. Any research with participants—especially minors—requires appropriate adult supervision, consent/assent, and school or institutional review as applicable.

## Roadmap

- [ ] Add an optional calm soundscape and sound toggle
- [ ] Add a guided tutorial level
- [ ] Add fixed daily puzzles for reproducible testing
- [ ] Add difficulty settings and evaluate player-reported challenge
- [ ] Add accessibility options (color-blind-safe palettes, reduced motion)
- [ ] Conduct playtests and revise based on feedback

## License

MIT. See `LICENSE`.
